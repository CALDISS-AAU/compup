python3 -m pip install tensorflow
git clone https://gitlab.com/brohrer/lodgepole.git
python3 -m pip install -e lodgepole
python3 -m pip install tensorflow_datasets
python3 -m pip install numba